// Production configuration for documentgpt.io
window.DOCUMENTGPT_CONFIG = {
    API_BASE_URL: 'https://9voqzgx3ch.execute-api.us-east-1.amazonaws.com/prod',
    ENVIRONMENT: 'production',
    VERSION: 'v5.0.0',
    FEATURES: {
        multiAgentDebate: true,
        realTimeStreaming: true,
        advancedOCR: true,
        exportCapabilities: true
    }
};
